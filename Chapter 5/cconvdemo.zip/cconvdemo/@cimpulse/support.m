function supp = support(sig)
supp = sig.Delay;